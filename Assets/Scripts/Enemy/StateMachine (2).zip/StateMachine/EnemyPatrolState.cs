using UnityEngine;

public class EnemyPatrolState
{
    
}
